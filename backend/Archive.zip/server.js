const awsServerlessExpress = require('aws-serverless-express');
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Use environment variables for sensitive information
const mongoURI = process.env.MONGODB_URI || 'mongodb+srv://bhashitha:AZaz09$$@cluster0amc.zcisnub.mongodb.net/test';

mongoose.connect(mongoURI)
  .then(() => console.log("Database connected"))
  .catch(err => console.error(err));

const movieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  genre: { type: String, required: true },
  year: { type: Number, required: true },
  imageUrl: { type: String, required: true },
});

const Movie = mongoose.model('Movie', movieSchema);

app.use(bodyParser.json());
app.use(cors());

app.get("/movies", async (req, res) => {
  try {
    const movies = await Movie.find();
    res.json(movies);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

// Create a server for aws-serverless-express
const server = awsServerlessExpress.createServer(app);

// Export the Lambda handler
exports.handler = (event, context) => {
  awsServerlessExpress.proxy(server, event, context);
};
